package utfpr.edu.br.pm46sturismo.data

import androidx.room.*
import utfpr.edu.br.pm46sturismo.model.PontoTuristico

/**
 * Interface DAO com operações de acesso ao banco de dados
 * para a entidade PontoTuristico.
 */
@Dao
interface PontoTuristicoDao {

    @Insert
    suspend fun inserir(ponto: PontoTuristico)

    @Update
    suspend fun atualizar(ponto: PontoTuristico)

    @Query("SELECT * FROM ponto_turistico ORDER BY favorito DESC, nome ASC")
    suspend fun listarTodos(): List<PontoTuristico>


    @Query("SELECT * FROM ponto_turistico WHERE id = :id")
    suspend fun buscarPorId(id: Int): PontoTuristico?

    @Delete
    fun excluir(ponto: PontoTuristico)
}