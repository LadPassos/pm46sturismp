package utfpr.edu.br.pm46sturismo.ui.activities

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import utfpr.edu.br.pm46sturismo.data.AppDatabase
import utfpr.edu.br.pm46sturismo.databinding.ActivityListaPontosBinding
import utfpr.edu.br.pm46sturismo.model.PontoTuristico
import utfpr.edu.br.pm46sturismo.ui.adapters.AdapterPonto
import utfpr.edu.br.pm46sturismo.util.PermissaoUtil

class ListaPontosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListaPontosBinding
    private lateinit var adapter: AdapterPonto
    private lateinit var listaCompleta: List<PontoTuristico>

    companion object {
        private const val REQUEST_PERMISSAO_LOCALIZACAO = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListaPontosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerPontos.layoutManager = LinearLayoutManager(this)

        CoroutineScope(Dispatchers.IO).launch {
            val pontos = AppDatabase.getDatabase(this@ListaPontosActivity)
                .pontoTuristicoDao()
                .listarTodos()

            runOnUiThread {
                if (PermissaoUtil.verificarPermissao(this@ListaPontosActivity, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    iniciarListaComLocalizacao(pontos)
                } else {
                    PermissaoUtil.solicitarPermissao(this@ListaPontosActivity, Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_PERMISSAO_LOCALIZACAO)
                }
            }
        }
    }

    private fun iniciarListaComLocalizacao(pontos: List<PontoTuristico>) {
        obterLocalizacaoAtual { localizacaoAtual ->
            listaCompleta = pontos
            adapter = AdapterPonto(pontos.toMutableList(), localizacaoAtual)
            binding.recyclerPontos.adapter = adapter

            binding.campoBusca.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val termo = s.toString().trim().lowercase()
                    val filtrados = listaCompleta.filter {
                        it.nome.lowercase().contains(termo)
                    }
                    adapter.atualizarLista(filtrados)
                }
            })
        }
    }

    @SuppressLint("MissingPermission")
    private fun obterLocalizacaoAtual(onLocalizacaoObtida: (Location?) -> Unit) {
        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location -> onLocalizacaoObtida(location) }
            .addOnFailureListener { onLocalizacaoObtida(null) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_PERMISSAO_LOCALIZACAO) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                CoroutineScope(Dispatchers.IO).launch {
                    val pontos = AppDatabase.getDatabase(this@ListaPontosActivity)
                        .pontoTuristicoDao()
                        .listarTodos()

                    runOnUiThread {
                        iniciarListaComLocalizacao(pontos)
                    }
                }
            } else {
                Toast.makeText(this, "Permissão de localização negada. Distância não será exibida.", Toast.LENGTH_LONG).show()
            }
        }
    }
}