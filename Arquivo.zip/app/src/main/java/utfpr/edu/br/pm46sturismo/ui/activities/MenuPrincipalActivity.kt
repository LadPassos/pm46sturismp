package utfpr.edu.br.pm46sturismo.ui.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import utfpr.edu.br.pm46sturismo.databinding.ActivityMenuPrincipalBinding

/**
 * Tela do menu principal com opções para acessar
 * as funcionalidades do app PM46S Turismo.
 */
class MenuPrincipalActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMenuPrincipalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuPrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.botaoCadastrar.setOnClickListener {
            startActivity(Intent(this, CadastroPontoActivity::class.java))
        }

        binding.botaoMapa.setOnClickListener {
            startActivity(Intent(this, MapaActivity::class.java))
        }

        binding.botaoLista.setOnClickListener {
            startActivity(Intent(this, ListaPontosActivity::class.java))
        }

        binding.botaoConfiguracoes.setOnClickListener {
            startActivity(Intent(this, ConfiguracoesActivity::class.java))
        }
    }
}