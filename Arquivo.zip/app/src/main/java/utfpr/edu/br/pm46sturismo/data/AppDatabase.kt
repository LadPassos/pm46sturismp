package utfpr.edu.br.pm46sturismo.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import utfpr.edu.br.pm46sturismo.model.PontoTuristico

/**
 * Classe abstrata que representa o banco de dados Room.
 * Inclui a entidade PontoTuristico e seu DAO.
 */
@Database(entities = [PontoTuristico::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

    abstract fun pontoTuristicoDao(): PontoTuristicoDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Obtém a instância singleton do banco de dados.
         */
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instancia = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pontos_turisticos.db"
                ).build()
                INSTANCE = instancia
                instancia
            }
        }
    }
}