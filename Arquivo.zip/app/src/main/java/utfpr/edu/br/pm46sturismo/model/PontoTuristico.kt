package utfpr.edu.br.pm46sturismo.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidade que representa um ponto turístico no banco de dados.
 *
 * @property id Identificador único (gerado automaticamente).
 * @property nome Nome do ponto turístico.
 * @property descricao Descrição do local.
 * @property latitude Coordenada de latitude.
 * @property longitude Coordenada de longitude.
 * @property imagem Caminho absoluto da imagem capturada.
 */
@Entity(tableName = "ponto_turistico")
data class PontoTuristico(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nome: String,
    val descricao: String,
    val latitude: Double,
    val longitude: Double,
    val imagem: String,
    val favorito: Boolean = false // novo campo
)