package utfpr.edu.br.pm46sturismo.ui.activities

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import utfpr.edu.br.pm46sturismo.data.AppDatabase
import utfpr.edu.br.pm46sturismo.model.PontoTuristico
import utfpr.edu.br.pm46sturismo.databinding.ActivityEditarPontoBinding
import java.io.File
import java.io.FileOutputStream

class EditarPontoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditarPontoBinding
    private var pontoId: Int = -1
    private lateinit var ponto: PontoTuristico
    private var caminhoImagem: String = ""

    companion object {
        const val REQUEST_CAMERA = 100
        const val REQUEST_GALERIA = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditarPontoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        pontoId = intent.getIntExtra("idPonto", -1)

        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.getDatabase(this@EditarPontoActivity).pontoTuristicoDao()
            ponto = dao.buscarPorId(pontoId) ?: return@launch
            caminhoImagem = ponto.imagem

            runOnUiThread {
                preencherCampos()
            }
        }

        binding.botaoFoto.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(intent, REQUEST_CAMERA)
        }

        binding.botaoGaleria.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, REQUEST_GALERIA)
        }

        binding.botaoSalvarAlteracoes.setOnClickListener {
            salvarAlteracoes()
        }
        binding.botaoExcluir.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Excluir Ponto")
                .setMessage("Tem certeza que deseja excluir este ponto turístico?")
                .setPositiveButton("Sim") { _, _ -> excluirPonto() }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun preencherCampos() {
        binding.editarNome.setText(ponto.nome)
        binding.editarDescricao.setText(ponto.descricao)
        binding.editarLatitude.setText(ponto.latitude.toString())
        binding.editarLongitude.setText(ponto.longitude.toString())
        binding.checkboxFavorito.isChecked = ponto.favorito
        try {
            val bitmap = BitmapFactory.decodeFile(caminhoImagem)
            binding.imagemPonto.setImageBitmap(bitmap)
        } catch (e: Exception) {
            binding.imagemPonto.setImageResource(android.R.drawable.ic_menu_report_image)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> {
                    val bitmap = data?.extras?.get("data") as? Bitmap
                    bitmap?.let {
                        caminhoImagem = salvarImagem(it)
                        binding.imagemPonto.setImageBitmap(it)
                    }
                }
                REQUEST_GALERIA -> {
                    val uri = data?.data
                    if (uri != null) {
                        val inputStream = contentResolver.openInputStream(uri)
                        val bitmap = BitmapFactory.decodeStream(inputStream)
                        inputStream?.close()
                        caminhoImagem = salvarImagem(bitmap)
                        binding.imagemPonto.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    private fun salvarImagem(bitmap: Bitmap): String {
        val nome = "ponto_edit_${System.currentTimeMillis()}.jpg"
        val arquivo = File(filesDir, nome)
        val out = FileOutputStream(arquivo)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)
        out.flush()
        out.close()
        return arquivo.absolutePath
    }

    private fun salvarAlteracoes() {
        val nome = binding.editarNome.text.toString()
        val descricao = binding.editarDescricao.text.toString()
        val lat = binding.editarLatitude.text.toString().toDoubleOrNull()
        val lon = binding.editarLongitude.text.toString().toDoubleOrNull()
        val favorito = binding.checkboxFavorito.isChecked

        if (nome.isBlank() || descricao.isBlank() || lat == null || lon == null) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        val pontoAtualizado = ponto.copy(
            nome = nome,
            descricao = descricao,
            latitude = lat,
            longitude = lon,
            imagem = caminhoImagem,
            favorito = favorito
        )

        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getDatabase(this@EditarPontoActivity)
                .pontoTuristicoDao()
                .atualizar(pontoAtualizado)

            runOnUiThread {
                Toast.makeText(this@EditarPontoActivity, "Ponto atualizado!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun excluirPonto() {
        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getDatabase(this@EditarPontoActivity)
                .pontoTuristicoDao()
                .excluir(ponto)

            runOnUiThread {
                Toast.makeText(
                    this@EditarPontoActivity,
                    "Ponto excluído com sucesso!",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

}