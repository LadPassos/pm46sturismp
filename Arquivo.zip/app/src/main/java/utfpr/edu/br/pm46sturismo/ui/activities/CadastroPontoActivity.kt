package utfpr.edu.br.pm46sturismo.ui.activities

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import utfpr.edu.br.pm46sturismo.data.AppDatabase
import utfpr.edu.br.pm46sturismo.databinding.ActivityCadastroPontoBinding
import utfpr.edu.br.pm46sturismo.model.PontoTuristico
import java.io.File
import java.io.FileOutputStream
import java.util.*

class CadastroPontoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroPontoBinding
    private var caminhoImagem: String = ""
    private val REQUEST_CAMERA = 100
    private val REQUEST_GALERIA = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroPontoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.botaoFoto.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(intent, REQUEST_CAMERA)
        }

        binding.botaoGaleria.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, REQUEST_GALERIA)
        }

        binding.botaoBuscarEndereco.setOnClickListener {
            val endereco = binding.campoEndereco.text.toString()
            if (endereco.isNotBlank()) {
                val geocoder = Geocoder(this, Locale.getDefault())
                try {
                    val resultados = geocoder.getFromLocationName(endereco, 1)
                    if (!resultados.isNullOrEmpty()) {
                        val local = resultados[0]
                        val lat = local.latitude
                        val lon = local.longitude

                        // Preenche os campos
                        binding.editarLatitude.setText(lat.toString())
                        binding.editarLongitude.setText(lon.toString())

                        // Abre o local no Google Maps
                        val uri = Uri.parse("geo:$lat,$lon?q=${Uri.encode(endereco)}")
                        val intent = Intent(Intent.ACTION_VIEW, uri)
                        intent.setPackage("com.google.android.apps.maps")
                        if (intent.resolveActivity(packageManager) != null) {
                            startActivity(intent)
                        } else {
                            Toast.makeText(this, "Google Maps não instalado", Toast.LENGTH_SHORT).show()
                        }

                    } else {
                        Toast.makeText(this, "Endereço não encontrado", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Erro ao buscar coordenadas", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Digite um endereço para buscar", Toast.LENGTH_SHORT).show()
            }
        }

        binding.botaoSalvar.setOnClickListener {
            salvarPonto()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> {
                    val bitmap = data?.extras?.get("data") as? Bitmap
                    bitmap?.let {
                        caminhoImagem = salvarImagem(it)
                        binding.imagemPonto.setImageBitmap(it)
                    }
                }
                REQUEST_GALERIA -> {
                    val uri = data?.data
                    if (uri != null) {
                        val inputStream = contentResolver.openInputStream(uri)
                        val bitmap = BitmapFactory.decodeStream(inputStream)
                        inputStream?.close()
                        caminhoImagem = salvarImagem(bitmap)
                        binding.imagemPonto.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    private fun salvarImagem(bitmap: Bitmap): String {
        val nome = "ponto_${System.currentTimeMillis()}.jpg"
        val arquivo = File(filesDir, nome)
        val out = FileOutputStream(arquivo)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)
        out.flush()
        out.close()
        return arquivo.absolutePath
    }

    private fun salvarPonto() {
        val nome = binding.editarNome.text.toString()
        val descricao = binding.editarDescricao.text.toString()
        val latitude = binding.editarLatitude.text.toString().toDoubleOrNull()
        val longitude = binding.editarLongitude.text.toString().toDoubleOrNull()

        if (nome.isBlank() || descricao.isBlank() || latitude == null || longitude == null) {
            Toast.makeText(this, "Preencha todos os campos obrigatórios", Toast.LENGTH_SHORT).show()
            return
        }

        val endereco = buscarEndereco(latitude, longitude)
        binding.textoEndereco.text = "Endereço: $endereco"

        val ponto = PontoTuristico(
            nome = nome,
            descricao = descricao,
            latitude = latitude,
            longitude = longitude,
            imagem = caminhoImagem // pode ser vazio, sem problema
        )

        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getDatabase(this@CadastroPontoActivity).pontoTuristicoDao().inserir(ponto)
            runOnUiThread {
                Toast.makeText(this@CadastroPontoActivity, "Ponto salvo com sucesso!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun buscarEndereco(lat: Double, lon: Double): String {
        return try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val resultado = geocoder.getFromLocation(lat, lon, 1)
            resultado?.get(0)?.getAddressLine(0) ?: "Endereço não encontrado"
        } catch (e: Exception) {
            "Erro ao buscar endereço"
        }
    }
}