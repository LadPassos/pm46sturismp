package utfpr.edu.br.pm46sturismo.ui.activities

import android.content.Context
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import utfpr.edu.br.pm46sturismo.databinding.ActivityConfiguracoesBinding

/**
 * Activity para configurar preferências do mapa:
 * tipo de visualização e nível de zoom.
 */
class ConfiguracoesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityConfiguracoesBinding
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConfiguracoesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("configuracoes", Context.MODE_PRIVATE)

        // Carrega valores salvos
        val tipoMapa = prefs.getInt("tipoMapa", 1)
        val zoomSalvo = prefs.getInt("zoom", 12)
        binding.seekZoom.progress = zoomSalvo
        binding.textZoomValor.text = "Zoom: $zoomSalvo"

        when (tipoMapa) {
            1 -> binding.opcaoNormal.isChecked = true
            2 -> binding.opcaoSatelite.isChecked = true
            3 -> binding.opcaoHibrido.isChecked = true
            4 -> binding.opcaoTerreno.isChecked = true
        }

        atualizarTextoTipoMapa() // Mostra o tipo de mapa salvo inicialmente

        // Atualiza texto do zoom e garante mínimo de 5
        binding.seekZoom.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val zoom = if (progress < 5) 5 else progress
                binding.textZoomValor.text = "Zoom: $zoom"
                if (progress < 5) seekBar?.progress = 5
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Atualiza o nome do tipo de mapa ao selecionar
        binding.opcaoNormal.setOnClickListener { atualizarTextoTipoMapa() }
        binding.opcaoSatelite.setOnClickListener { atualizarTextoTipoMapa() }
        binding.opcaoHibrido.setOnClickListener { atualizarTextoTipoMapa() }
        binding.opcaoTerreno.setOnClickListener { atualizarTextoTipoMapa() }

        // Salvar configurações
        binding.botaoSalvarConfiguracoes.setOnClickListener {
            val tipoSelecionado = when (binding.grupoTipoMapa.checkedRadioButtonId) {
                binding.opcaoNormal.id -> 1
                binding.opcaoSatelite.id -> 2
                binding.opcaoHibrido.id -> 3
                binding.opcaoTerreno.id -> 4
                else -> 1
            }

            prefs.edit()
                .putInt("zoom", binding.seekZoom.progress)
                .putInt("tipoMapa", tipoSelecionado)
                .apply()

            Toast.makeText(this, "Configurações salvas", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    /**
     * Atualiza o texto do tipo de mapa selecionado dinamicamente.
     */
    private fun atualizarTextoTipoMapa() {
        val tipoTexto = when {
            binding.opcaoSatelite.isChecked -> "Satélite"
            binding.opcaoHibrido.isChecked -> "Híbrido"
            binding.opcaoTerreno.isChecked -> "Terreno"
            else -> "Normal"
        }
        binding.textTipoSelecionado.text = "Tipo selecionado: $tipoTexto"
    }
}