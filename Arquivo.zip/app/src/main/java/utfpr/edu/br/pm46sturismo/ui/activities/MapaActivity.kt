package utfpr.edu.br.pm46sturismo.ui.activities

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import utfpr.edu.br.pm46sturismo.R
import utfpr.edu.br.pm46sturismo.data.AppDatabase
import utfpr.edu.br.pm46sturismo.model.PontoTuristico
import utfpr.edu.br.pm46sturismo.databinding.ActivityMapaBinding

/**
 * Activity que exibe todos os pontos turísticos cadastrados no Google Maps.
 * Exibe detalhes ao clicar em um marcador.
 */
class MapaActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityMapaBinding
    private lateinit var mapa: GoogleMap
    private var listaPontos: List<PontoTuristico> = listOf()
    private val marcadorParaPonto = mutableMapOf<Marker, PontoTuristico>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.mapa) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // Carregar pontos em background
        CoroutineScope(Dispatchers.IO).launch {
            listaPontos = AppDatabase.getDatabase(this@MapaActivity)
                .pontoTuristicoDao()
                .listarTodos()

            runOnUiThread {
                carregarPontosNoMapa()
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mapa = googleMap

        val prefs = getSharedPreferences("configuracoes", Context.MODE_PRIVATE)
        val tipoMapa = prefs.getInt("tipoMapa", 1)
        val zoom = prefs.getInt("zoom", 12).toFloat()

        mapa.mapType = when (tipoMapa) {
            2 -> GoogleMap.MAP_TYPE_SATELLITE
            3 -> GoogleMap.MAP_TYPE_HYBRID
            4 -> GoogleMap.MAP_TYPE_TERRAIN
            else -> GoogleMap.MAP_TYPE_NORMAL
        }

        mapa.setInfoWindowAdapter(object : GoogleMap.InfoWindowAdapter {
            override fun getInfoWindow(marker: Marker): View? = null

            override fun getInfoContents(marker: Marker): View {
                val view = layoutInflater.inflate(R.layout.item_info_window, null)
                val ponto = marcadorParaPonto[marker]

                val imagemView = view.findViewById<ImageView>(R.id.imagemInfo)
                val textoNome = view.findViewById<TextView>(R.id.textoNome)
                val textoDescricao = view.findViewById<TextView>(R.id.textoDescricao)
                val textoCoordenadas = view.findViewById<TextView>(R.id.textoCoordenadas)

                textoNome.text = ponto?.nome
                textoDescricao.text = ponto?.descricao
                textoCoordenadas.text = "(${ponto?.latitude}, ${ponto?.longitude})"

                // Carrega a imagem do caminho salvo
                try {
                    val bitmap = ponto?.imagem?.let { caminho ->
                        android.graphics.BitmapFactory.decodeFile(caminho)
                    }
                    imagemView.setImageBitmap(bitmap)
                } catch (e: Exception) {
                    imagemView.setImageResource(android.R.drawable.ic_menu_report_image)
                }

                return view
            }
        })
    }

    private fun carregarPontosNoMapa() {
        if (!::mapa.isInitialized) return

        if (listaPontos.isNotEmpty()) {
            for (ponto in listaPontos) {
                val posicao = LatLng(ponto.latitude, ponto.longitude)
                val marcador = mapa.addMarker(
                    MarkerOptions()
                        .position(posicao)
                        .title(ponto.nome)
                )
                if (marcador != null) {
                    marcadorParaPonto[marcador] = ponto
                }
            }

            val primeiro = LatLng(listaPontos[0].latitude, listaPontos[0].longitude)
            mapa.moveCamera(CameraUpdateFactory.newLatLngZoom(primeiro, 12f))
        }
    }
}