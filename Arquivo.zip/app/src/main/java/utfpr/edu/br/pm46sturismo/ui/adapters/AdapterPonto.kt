package utfpr.edu.br.pm46sturismo.ui.adapters

import android.content.Intent
import android.graphics.BitmapFactory
import android.location.Location
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import utfpr.edu.br.pm46sturismo.databinding.ItemPontoBinding
import utfpr.edu.br.pm46sturismo.model.PontoTuristico
import utfpr.edu.br.pm46sturismo.ui.activities.EditarPontoActivity
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Adapter para exibir os pontos turísticos em uma RecyclerView.
 */
class AdapterPonto(
    private val lista: MutableList<PontoTuristico>,
    private val localizacaoAtual: Location?
) : RecyclerView.Adapter<AdapterPonto.PontoViewHolder>() {

    /**
     * ViewHolder com ViewBinding.
     */
    inner class PontoViewHolder(val binding: ItemPontoBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PontoViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemPontoBinding.inflate(layoutInflater, parent, false)
        return PontoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PontoViewHolder, position: Int) {
        val ponto = lista[position]
        with(holder.binding) {
            textoNome.text = ponto.nome
            textoDescricao.text = ponto.descricao
            textoCoordenadas.text = "(${ponto.latitude}, ${ponto.longitude})"

            try {
                val bitmap = BitmapFactory.decodeFile(ponto.imagem)
                imagemItem.setImageBitmap(bitmap)
            } catch (e: Exception) {
                imagemItem.setImageResource(android.R.drawable.ic_menu_gallery)
            }

            // Calcula e exibe a distância, se a localização estiver disponível
            if (localizacaoAtual != null) {
                val pontoLocation = Location("").apply {
                    latitude = ponto.latitude
                    longitude = ponto.longitude
                }

                val distanciaMetros = localizacaoAtual.distanceTo(pontoLocation)
                val distanciaKm = distanciaMetros / 1000.0

                textoDistanciaPonto.text = String.format(Locale.getDefault(), "Distância: %.2f km", distanciaKm)
            } else {
                textoDistanciaPonto.text = "Distância: desconhecida"
            }

            // Clique para editar
            root.setOnClickListener {
                val contexto = root.context
                val intent = Intent(contexto, EditarPontoActivity::class.java)
                intent.putExtra("idPonto", ponto.id)
                contexto.startActivity(intent)
            }
        }
    }

    override fun getItemCount(): Int = lista.size

    /**
     * Atualiza a lista exibida com base no filtro de busca.
     */
    fun atualizarLista(novaLista: List<PontoTuristico>) {
        lista.clear()
        lista.addAll(novaLista)
        notifyDataSetChanged()
    }
}